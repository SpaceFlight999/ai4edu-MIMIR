import { mkdir, writeFile } from 'node:fs/promises';
const save = (name, value) => writeFile(new URL(name, import.meta.url), value, 'utf8');
await mkdir(new URL('./svg/', import.meta.url), { recursive: true });
const m = 'M40 218V211L51 209Q62 207 62 193V91Q62 77 49 75L40 73V66H87L151 177L215 66H254V73L244 75Q234 77 234 91V193Q234 207 246 209L255 211V218H188V211L201 209Q212 207 212 193V97L148 207H139L75 97V193Q75 207 87 209L101 211V218Z';
const i = 'M295 66H367V73L350 76Q343 77 343 89V195Q343 207 355 209L367 211V218H295V211L307 209Q319 207 319 195V89Q319 77 307 75L295 73Z';
const r = 'M780 66H849C896 66 922 80 922 107C922 133 904 146 880 151L918 202Q924 211 940 212V218H902L855 154H829V194Q829 207 842 209L853 211V218H780V211L791 209Q804 207 804 194V90Q804 77 791 75L780 73ZM829 78V142H848C881 142 895 130 895 108C895 86 880 78 849 78Z';
const letters = `<path d="${m}"/><path d="${i}"/><path d="${m}" transform="translate(370)"/><path d="${i}" transform="translate(370)"/><path fill-rule="evenodd" d="${r}"/>`;
const sparks = '<path d="M331 24L339 36L331 48L323 36Z M701 24L709 36L701 48L693 36Z"/>';
const variants = {
  primary: { colors: ['#3D506C', '#728BAE', '#7B769D'], accent: '#B79768' },
  night: { colors: ['#EAF0FA', '#BBCFE7', '#CFC4E4'], accent: '#E2C796' },
  mono: { solid: 'currentColor', accent: 'currentColor' },
  white: { solid: '#FFFFFF', accent: '#FFFFFF' },
};
function artwork(name, prefix = name) {
  const v = variants[name];
  const defs = v.colors ? `<defs><linearGradient id="${prefix}-ink" x1="40" y1="66" x2="940" y2="218" gradientUnits="userSpaceOnUse"><stop stop-color="${v.colors[0]}"/><stop offset=".53" stop-color="${v.colors[1]}"/><stop offset="1" stop-color="${v.colors[2]}"/></linearGradient></defs>` : '';
  return `${defs}<g fill="${v.solid || `url(#${prefix}-ink)`}">${letters}</g><g fill="${v.accent}">${sparks}</g>`;
}
for (const name of Object.keys(variants)) {
  await save(`svg/mimir-${name}.svg`, `<svg xmlns="http://www.w3.org/2000/svg" width="960" height="260" viewBox="0 0 960 260" role="img" aria-label="MIMIR"><title>MIMIR — Wisdom in flow</title><desc>Custom outlined wordmark with flared serifs and two diamond accents.</desc>${artwork(name)}</svg>\n`);
}
const preview = `<svg xmlns="http://www.w3.org/2000/svg" width="1600" height="1120" viewBox="0 0 1600 1120">
<rect width="1600" height="1120" fill="#F7F6F2"/>
<g font-family="Segoe UI,Arial,sans-serif" fill="#35435B">
<text x="88" y="81" font-size="18" letter-spacing="4">MIMIR / WORDMARK</text>
<text x="1512" y="81" text-anchor="end" font-size="14" letter-spacing="2" fill="#79818F">01 — WISDOM IN FLOW</text>
<path d="M88 110H1512" stroke="#D9DCE1"/>
<text x="800" y="211" text-anchor="middle" font-size="12" letter-spacing="6" fill="#8C8275">A QUIET SPARK. AN OPEN MIND.</text>
<g transform="translate(176 242) scale(1.3)">${artwork('primary', 'hero')}</g>
<text x="800" y="571" text-anchor="middle" font-size="13" letter-spacing="3" fill="#7B8494">CUSTOM LETTERFORMS / MIST BLUE / WARM GOLD</text>
<rect x="88" y="637" width="698" height="324" rx="4" fill="#202B3E"/>
<text x="120" y="680" font-size="12" letter-spacing="2" fill="#B9C8DD">02 / AFTER DARK</text>
<g transform="translate(124 726) scale(.65)">${artwork('night', 'after-dark')}</g>
<rect x="810" y="637" width="702" height="324" rx="4" fill="#FFFFFF" stroke="#E3E4E7"/>
<text x="844" y="680" font-size="12" letter-spacing="2" fill="#7D8591">03 / PURE FORM</text>
<g color="#303645" transform="translate(848 726) scale(.65)">${artwork('mono', 'pure')}</g>
<path d="M88 1010H1512" stroke="#D9DCE1"/>
<text x="88" y="1054" font-size="13" letter-spacing="2" fill="#7D8591">SCALABLE VECTORS. NO FONT REQUIRED.</text>
<g transform="translate(1076 1036)"><circle r="7" fill="#3D506C"/><circle cx="26" r="7" fill="#728BAE"/><circle cx="52" r="7" fill="#7B769D"/><circle cx="78" r="7" fill="#B79768"/></g>
<text x="1512" y="1054" text-anchor="end" font-size="13" letter-spacing="2" fill="#7D8591">MIMIR / 2026</text>
</g></svg>`;
await save('preview.svg', preview);
console.log('Generated 4 standalone SVGs and preview.svg.');
