# MIMIR 艺术字资源包

设计方向：**智慧之泉 · 静谧灵光**。自绘高对比字形、楔形衬线与两枚菱形灵光，结合项目现有雾蓝与灰紫色。所有字形均为矢量路径，不依赖字体文件、在线服务或前端框架。

## 选择文件

| 版本 | SVG | 用途 |
| --- | --- | --- |
| 标准彩色 | `svg/mimir-primary.svg` | 白色、米白、浅灰背景，首选 |
| 深色适配 | `svg/mimir-night.svg` | 深蓝、炭黑背景，浅色渐变 |
| 单色 | `svg/mimir-mono.svg` | 默认黑色；内联 SVG 时跟随 CSS `color` |
| 纯白 | `svg/mimir-white.svg` | 深色背景、反白排版 |

四个 SVG 与对应的 `png/` 高清 PNG 均为**透明底**。PNG 尺寸为 2400 × 650；`preview.png` 和 `preview.svg` 是带背景的展示板，不作为透明字标使用。

SVG 画布比例为 48:13，宽高为 960 × 260，已留出基本边距。建议展示宽度不低于 160px；小尺寸导航优先使用单色版。保持原比例，勿拉伸。对外排版建议额外留出至少一个字干宽度的空间。

## 最通用：直接复制引用

把所需 SVG 复制到另一个项目的 `public/brand/`，即可用于 HTML、React、Vue 或其他框架：

```html
<img src="/brand/mimir-primary.svg" alt="MIMIR" width="240" height="65" />
```

这里的 `/brand/` 是示例部署路径；子目录部署时请使用项目实际的资源基础路径。

```css
.mimir-wordmark { display: block; width: 240px; max-width: 100%; height: auto; }
```

深色背景将文件名换成 `mimir-night.svg` 或 `mimir-white.svg`。PPT、文档和图片编辑器可插入 SVG；不支持 SVG 的软件使用 PNG。

## 可选：作为本地包调用

将本目录完整复制到目标工程附近，在目标工程中运行：

```sh
npm install ../mimir-wordmark
```

使用支持 `new URL(..., import.meta.url)` 资源处理的 ESM 构建工具：

```jsx
import { primary, night } from '@mimir/wordmark';

export function Brand({ dark = false }) {
  return <img src={dark ? night : primary} alt="MIMIR" width={240} height={65} />;
}
```

这个包仅导出资源 URL，没有运行时依赖，也没有发布到公共 npm 仓库。Node.js 中导出的是本机 `file:` URL，不能直接作为远程浏览器地址；服务端渲染项目优先使用 `public/brand/` 方式，或按框架规则导入静态资源。

## 改色与编辑

- 默认推荐 `<img>` 引用，多个实例互不影响。
- 单色版使用 `fill="currentColor"`。**只有内联 SVG 才能继承外部 CSS `color`**；通过 `<img>` 引用不会继承父页面颜色。
- 内联多个彩色版时，为每个实例的渐变 `id` 及对应 `url(#...)` 添加唯一前缀，避免重名。
- 可在 Figma、Illustrator、Inkscape 等支持 SVG 的工具中编辑路径。
- `build.mjs` 保存完整路径数据与配色。执行 `node build.mjs` 可重新生成 SVG 与展示板 SVG；该命令不更新 PNG，修改后需重新导出 PNG。

主色：`#3D506C`、`#728BAE`、`#7B769D`。点缀：`#B79768`。深色背景建议：`#202B3E`。

本次交付仅新增独立资源包，未自动替换 MIMIR 应用内的现有标题或标识。
